<!doctype html>
<html lang="en" data-theme="dark">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light dark"><script>(()=>{try{const saved=localStorage.getItem('kipanya-theme');if(saved==='light'||saved==='dark')document.documentElement.dataset.theme=saved;}catch(_){} })();</script><meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"><title><?php echo e($title ?? 'Kipanya'); ?></title>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
</head>
<body class="antialiased kipanya-platform platform-client">
<?php if (isset($component)) { $__componentOriginal561a05b5eb862a3bdec2028663814664 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal561a05b5eb862a3bdec2028663814664 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.client-nav','data' => ['activeApp' => 'home','brandSubtitle' => 'Kipanya','searchAction' => ''.e(route('discover')).'','searchPlaceholder' => 'Search stories, cartoons...','searchLabel' => 'Search Kipanya','showFavorites' => false,'showCart' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('client-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['active-app' => 'home','brand-subtitle' => 'Kipanya','search-action' => ''.e(route('discover')).'','search-placeholder' => 'Search stories, cartoons...','search-label' => 'Search Kipanya','show-favorites' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'show-cart' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal561a05b5eb862a3bdec2028663814664)): ?>
<?php $attributes = $__attributesOriginal561a05b5eb862a3bdec2028663814664; ?>
<?php unset($__attributesOriginal561a05b5eb862a3bdec2028663814664); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal561a05b5eb862a3bdec2028663814664)): ?>
<?php $component = $__componentOriginal561a05b5eb862a3bdec2028663814664; ?>
<?php unset($__componentOriginal561a05b5eb862a3bdec2028663814664); ?>
<?php endif; ?>
<main><?php echo e($slot ?? ''); ?><?php echo $__env->yieldContent('content'); ?></main>
<footer class="platform-footer"><div class="platform-shell"><a href="<?php echo e(route('home')); ?>" class="platform-wordmark"><span class="platform-mark">K</span><span>Kipanya</span></a><p>Stories, culture, style and moments worth sharing.</p><div class="platform-footer-links"><a href="<?php echo e(route('cartoon')); ?>">Cartoons</a><a href="<?php echo e(route('wear')); ?>">Wear</a><a href="<?php echo e(route('discover')); ?>">Discover</a><a href="<?php echo e(auth()->check() ? route('account') : route('account.login')); ?>">My Kipanya</a></div></div></footer>
</body></html>
<?php /**PATH C:\Users\DIGITAL STAR\kipanya-platform\kipanya-platform\resources\views/layouts/app.blade.php ENDPATH**/ ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'categoryMeta' => [],
    'categoryCounts' => collect(),
    'sizeOptions' => [],
    'colorOptions' => [],
    'priceMin' => 0,
    'priceMax' => 0,
    'colorHex' => [],
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'categoryMeta' => [],
    'categoryCounts' => collect(),
    'sizeOptions' => [],
    'colorOptions' => [],
    'priceMin' => 0,
    'priceMax' => 0,
    'colorHex' => [],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<aside class="wear-store-sidebar" aria-label="Wear shop filters">
    <a href="<?php echo e(route('wear')); ?>" class="wear-store-side-logo">
        <span class="wear-store-side-logo-mark">K</span>
        <span><strong>KIPANYA</strong><small>WEAR</small></span>
    </a>

    <form class="wear-filter-panel" data-wear-filters>
        <div class="wear-filter-head">
            <div>
                <span>SHOP</span>
                <strong>Find your fit</strong>
            </div>
            <button type="button" data-wear-clear>Clear</button>
        </div>

        
        <div class="wear-filter-group">
            <div class="wear-filter-group-head"><strong>Category</strong></div>
            <label class="wear-check-row">
                <input type="radio" name="category" value="" <?php if(!request('category')): echo 'checked'; endif; ?>>
                <span>All products</span>
                <b><?php echo e($categoryCounts->sum()); ?></b>
            </label>
            <?php $__currentLoopData = $categoryMeta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $meta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="wear-check-row">
                    <input type="radio" name="category" value="<?php echo e($category); ?>" <?php if(request('category') === $category): echo 'checked'; endif; ?>>
                    <span><?php echo e($category); ?></span>
                    <b><?php echo e($categoryCounts[$category] ?? 0); ?></b>
                </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div class="wear-filter-group">
            <div class="wear-filter-group-head">
                <strong>Price range</strong>
                <span>TSh <?php echo e(number_format((int) $priceMin, 0)); ?> – TSh <?php echo e(number_format((int) $priceMax, 0)); ?></span>
            </div>
            <div class="wear-price-range">
                <input type="range" min="<?php echo e((int) $priceMin); ?>" max="<?php echo e((int) $priceMax); ?>" step="1000"
                       value="<?php echo e(request('min_price', (int) $priceMin)); ?>" data-price-min>
                <input type="range" min="<?php echo e((int) $priceMin); ?>" max="<?php echo e((int) $priceMax); ?>" step="1000"
                       value="<?php echo e(request('max_price', (int) $priceMax)); ?>" data-price-max>
            </div>
            <div class="wear-price-inputs">
                <input type="number" min="0" step="1000" name="min_price" value="<?php echo e(request('min_price')); ?>"
                       placeholder="Min" data-price-min-input>
                <span>—</span>
                <input type="number" min="0" step="1000" name="max_price" value="<?php echo e(request('max_price')); ?>"
                       placeholder="Max" data-price-max-input>
            </div>
        </div>

        
        <div class="wear-filter-group">
            <div class="wear-filter-group-head"><strong>Size</strong></div>
            <div class="wear-filter-chips">
                <?php $__currentLoopData = $sizeOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label>
                        <input type="checkbox" name="sizes[]" value="<?php echo e($size); ?>"
                               <?php if(in_array($size, (array) request('sizes', []), true)): echo 'checked'; endif; ?>>
                        <span><?php echo e($size); ?></span>
                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        
        <div class="wear-filter-group">
            <div class="wear-filter-group-head"><strong>Color</strong></div>
            <div class="wear-color-filter">
                <?php $__currentLoopData = $colorOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label title="<?php echo e(ucfirst($color)); ?>">
                        <input type="checkbox" name="colors[]" value="<?php echo e($color); ?>"
                               <?php if(in_array($color, (array) request('colors', []), true)): echo 'checked'; endif; ?>>
                        <span style="--swatch: <?php echo e($colorHex[strtolower($color)] ?? '#111827'); ?>"></span>
                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        
        <div class="wear-filter-group">
            <div class="wear-filter-group-head"><strong>Availability</strong></div>
            <label class="wear-check-row">
                <input type="checkbox" name="in_stock" value="1" <?php if(request()->boolean('in_stock')): echo 'checked'; endif; ?>>
                <span>In stock</span>
            </label>
            <label class="wear-check-row">
                <input type="checkbox" name="on_sale" value="1" <?php if(request()->boolean('on_sale')): echo 'checked'; endif; ?>>
                <span>On sale</span>
            </label>
        </div>
    </form>

    <div class="wear-side-trust">
        <div>
            <span><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'shield','size' => '16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'shield','size' => '16']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span>
            <strong>Original Art</strong>
            <small>Kipanya designs</small>
        </div>
        <div>
            <span><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'package','size' => '16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'package','size' => '16']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span>
            <strong>Fast Delivery</strong>
            <small>Across Tanzania</small>
        </div>
        <div>
            <span><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'lock','size' => '16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'lock','size' => '16']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span>
            <strong>Secure Payment</strong>
            <small>Protected checkout</small>
        </div>
    </div>
</aside>
<?php /**PATH C:\Users\DIGITAL STAR\kipanya-platform\kipanya-platform\resources\views/components/wear/filters.blade.php ENDPATH**/ ?>
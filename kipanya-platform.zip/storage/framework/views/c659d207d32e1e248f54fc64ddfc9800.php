<!doctype html>
<html lang="en" data-theme="light">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light dark"><meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"><title><?php echo e($title ?? 'Kipanya'); ?></title><?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?></head>
<body class="antialiased">
<header class="sticky top-0 z-40 border-b k-divider bg-[color:var(--bg)]/90 backdrop-blur-xl">
<div class="k-shell flex h-18 items-center gap-6">
<a href="<?php echo e(route('home')); ?>" class="flex items-center gap-2 text-lg font-bold tracking-tight"><span class="grid h-8 w-8 place-items-center rounded-xl bg-[var(--accent)] text-white">K</span>KIPANYA</a>
<nav class="hidden items-center gap-1 md:flex"><a class="k-nav-link rounded-lg px-3 py-2 text-sm <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">Home</a><a class="k-nav-link rounded-lg px-3 py-2 text-sm <?php echo e(request()->routeIs('discover','category','collection') ? 'active' : ''); ?>" href="<?php echo e(route('discover')); ?>">Discover</a><a class="k-nav-link rounded-lg px-3 py-2 text-sm" href="<?php echo e(route('home')); ?>#latest">Latest</a></nav>
<div class="ml-auto flex items-center gap-2">
<form action="<?php echo e(route('discover')); ?>" method="GET" class="hidden lg:block"><div class="k-control flex w-64 items-center gap-2 rounded-xl px-3"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'search','size' => '16','class' => 'shrink-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'search','size' => '16','class' => 'shrink-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?><input name="q" value="<?php echo e(request('q')); ?>" placeholder="Search cartoons..." class="w-full border-0 bg-transparent py-2.5 text-xs outline-none"/></div></form>
<button data-theme-toggle class="k-btn k-btn-light h-10 w-10 p-0" aria-label="Toggle color theme"><span data-theme-icon data-theme-icon-light='<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/><circle cx="12" cy="12" r="4"/></svg>' data-theme-icon-dark='<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20.5 15.5A8.5 8.5 0 0 1 8.5 3.5 8.5 8.5 0 1 0 20.5 15.5Z"/></svg>'></span></button>
<a href="<?php echo e(auth()->check() ? route('account') : route('account.login')); ?>" class="hidden k-btn k-btn-light sm:inline-flex"><?php echo e(auth()->check() ? 'Account' : 'Sign in'); ?></a><a href="<?php echo e(route('admin.login')); ?>" class="hidden k-btn k-btn-light lg:inline-flex">Studio</a><button data-menu-toggle="#mobile-menu" class="k-btn k-btn-light md:hidden" aria-label="Open menu"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'menu']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'menu']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></button>
</div></div>
<div id="mobile-menu" class="k-shell hidden border-t k-divider py-4 md:hidden"><div class="grid gap-1"><a class="k-nav-link rounded-lg px-3 py-3" href="<?php echo e(route('home')); ?>">Home</a><a class="k-nav-link rounded-lg px-3 py-3" href="<?php echo e(route('discover')); ?>">Discover</a><a class="k-nav-link rounded-lg px-3 py-3" href="<?php echo e(route('home')); ?>#latest">Latest</a><a class="k-nav-link rounded-lg px-3 py-3" href="<?php echo e(route('admin.login')); ?>">Studio</a></div></div>
</header>
<main><?php echo e($slot ?? ''); ?><?php echo $__env->yieldContent('content'); ?></main>
<footer class="mt-24 border-t k-divider"><div class="k-shell flex flex-col gap-6 py-12 text-sm sm:flex-row sm:items-end sm:justify-between"><div><div class="flex items-center gap-2 font-semibold"><span class="grid h-7 w-7 place-items-center rounded-lg bg-[var(--accent)] text-xs text-white">K</span>KIPANYA</div><p class="mt-3 max-w-sm leading-6 k-muted">Stories, characters and moments worth sharing.</p></div><div class="flex items-center gap-4"><button data-theme-toggle class="k-btn k-btn-light" type="button"><span data-theme-label>Dark mode</span></button><span class="k-muted">© <?php echo e(date('Y')); ?> Kipanya</span></div></div></footer>
</body></html>
<?php /**PATH C:\Users\Esrom Mussa\kipanya-platform\resources\views/layouts/app.blade.php ENDPATH**/ ?>
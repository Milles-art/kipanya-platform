<?php $__env->startSection('content'); ?>
<section class="k-shell flex min-h-[75vh] items-center justify-center py-16">
    <div class="w-full max-w-md">
        <div class="k-label text-black/40">Kipanya Studio</div>
        <h1 class="mt-4 text-4xl font-semibold tracking-tight">Sign in to your workspace.</h1>
        <p class="mt-4 leading-7 text-black/55">Use the administrator phone number to receive a secure verification code.</p>

        <?php if(session('status')): ?>
            <div class="mt-6 rounded-2xl bg-[#f1f1ef] p-4 text-sm">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="mt-6 rounded-2xl bg-red-50 p-4 text-sm text-red-700">
                <?php echo e($errors->first()); ?>

            </div>
        <?php endif; ?>

        <form class="mt-8 space-y-4" method="POST" action="<?php echo e(route('admin.login.request-otp')); ?>">
            <?php echo csrf_field(); ?>
            <label class="block">
                <span class="k-label text-black/40">Phone number</span>
                <input name="phone" value="<?php echo e(old('phone')); ?>" required class="k-focus mt-2 w-full rounded-2xl border border-black/10 bg-white px-4 py-3.5" placeholder="0712 345 678">
            </label>
            <button type="submit" class="k-btn k-btn-dark w-full">Send verification code</button>
        </form>

        <?php if(session('admin_login_phone')): ?>
            <form class="mt-4 space-y-4" method="POST" action="<?php echo e(route('admin.login.verify')); ?>">
                <?php echo csrf_field(); ?>
                <label class="block">
                    <span class="k-label text-black/40">Verification code</span>
                    <input name="code" inputmode="numeric" maxlength="6" required class="k-focus mt-2 w-full rounded-2xl border border-black/10 bg-white px-4 py-3.5 text-center text-2xl tracking-[.35em]" placeholder="000000">
                </label>
                <button type="submit" class="k-btn k-btn-accent w-full">Enter Studio</button>
            </form>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Esrom Mussa\kipanya-platform\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="cartoon-archive-page">
    <div class="cartoon-archive-workspace">
        <div class="cartoon-archive-main">
            <?php if($daily->count()): ?>
            <section class="cartoon-home-section cartoon-daily-section cartoon-daily-first" id="daily-stories" aria-labelledby="daily-cartoon-heading">
                <div class="cartoon-section-head-react">
                    <div><div class="cartoon-section-label">Every day</div><h1 id="daily-cartoon-heading">Daily Cartoon</h1></div>
                    <a href="<?php echo e(route('cartoon.search', ['daily' => 1])); ?>">View all <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'arrow-right','size' => '15']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','size' => '15']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></a>
                </div>
                <div class="cartoon-story-row" data-daily-stories aria-label="Daily Cartoon stories">
                    <?php $__currentLoopData = $daily; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $storyDate = $item->daily_date?->format('D') ?? $item->published_at?->format('D');
                            $storyFullDate = ($item->daily_date ?: $item->published_at)?->format('l, d M Y');
                            $storyCaption = trim((string) ($item->caption ?: $item->description));
                            $storyIsToday = (($item->daily_date ?: $item->published_at)?->isToday()) === true;
                        ?>
                        <button type="button" class="cartoon-story" data-story-index="<?php echo e($index); ?>" data-story-image="<?php echo e($item->resolved_thumbnail_url); ?>" data-story-title="<?php echo e($item->title); ?>" data-story-caption="<?php echo e($storyCaption); ?>" data-story-date="<?php echo e($storyFullDate); ?>" data-story-detail="<?php echo e(route('cartoon.detail', $item)); ?>" data-story-wear="<?php echo e(route('wear.design', $item)); ?>" aria-label="Open <?php echo e($item->title); ?> story">
                            <span class="cartoon-story-ring <?php echo e($index === 0 ? 'is-today' : ''); ?>"><span class="cartoon-story-image"><?php if($item->resolved_thumbnail_url): ?><img src="<?php echo e($item->resolved_thumbnail_url); ?>" alt="" loading="lazy"><?php endif; ?></span></span>
                            <strong><?php echo e($storyIsToday ? 'Today' : $storyDate); ?></strong>
                            <small><?php echo e($item->daily_date?->format('d M') ?? $item->published_at?->format('d M')); ?></small>
                        </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
            <?php endif; ?>

            <?php
                $categoryIcons = [
                    'everyday-life' => 'home',
                    'humor' => 'chat',
                    'society' => 'users',
                    'family' => 'heart',
                    'culture' => 'book',
                    'work-business' => 'bag',
                ];
            ?>
            <section class="cartoon-home-section cartoon-categories-top" id="categories">
                <div class="cartoon-section-head-react"><div><div class="cartoon-section-label">Explore</div><h2>Browse Categories</h2></div><a href="<?php echo e(route('cartoon.search')); ?>">View all <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'arrow-right','size' => '15']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','size' => '15']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></a></div>
                <div class="cartoon-category-grid-react">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $categoryIcon = $categoryIcons[$category->slug] ?? 'grid'; ?>
                        <a href="<?php echo e(route('category', $category)); ?>" class="cartoon-category-card-react">
                            <span class="cartoon-category-icon"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => ''.e($categoryIcon).'','size' => '20']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e($categoryIcon).'','size' => '20']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span>
                            <strong><?php echo e($category->name); ?></strong>
                            <small><?php echo e($category->cartoons_count); ?> cartoons</small>
                            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'arrow-right','size' => '13']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','size' => '13']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>

            <section class="cartoon-home-section" id="latest">
                <div class="cartoon-section-head-react"><div><div class="cartoon-section-label">Archive</div><h2>Latest from the Archive</h2></div><a href="<?php echo e(route('cartoon.search')); ?>">View all <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'arrow-right','size' => '15']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','size' => '15']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></a></div>
                <div class="cartoon-grid-react">
                    <?php $__empty_1 = true; $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartoon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if (isset($component)) { $__componentOriginal10601f9f8b334c649e4027adc83e5309 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal10601f9f8b334c649e4027adc83e5309 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cartoon.card','data' => ['cartoon' => $cartoon]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cartoon.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['cartoon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($cartoon)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal10601f9f8b334c649e4027adc83e5309)): ?>
<?php $attributes = $__attributesOriginal10601f9f8b334c649e4027adc83e5309; ?>
<?php unset($__attributesOriginal10601f9f8b334c649e4027adc83e5309); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal10601f9f8b334c649e4027adc83e5309)): ?>
<?php $component = $__componentOriginal10601f9f8b334c649e4027adc83e5309; ?>
<?php unset($__componentOriginal10601f9f8b334c649e4027adc83e5309); ?>
<?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="cartoon-empty">No published cartoons yet.</div><?php endif; ?>
                </div>
            </section>

            <section class="cartoon-home-section" id="collections">
                <div class="cartoon-section-head-react"><div><div class="cartoon-section-label">Curated</div><h2>Collections</h2></div><a href="<?php echo e(route('collections')); ?>">Explore <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'arrow-right','size' => '15']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','size' => '15']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></a></div>
                <div class="cartoon-collection-grid-react">
                    <?php $__empty_1 = true; $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href="<?php echo e(route('collection', $collection)); ?>" class="cartoon-collection-card-react">
                            <div class="cartoon-collection-cover">
                                <?php if($collection->resolved_cover_url): ?><img src="<?php echo e($collection->resolved_cover_url); ?>" alt="<?php echo e($collection->name); ?>" loading="lazy">
                                <?php elseif($collection->cartoons->first()?->resolved_thumbnail_url): ?><img src="<?php echo e($collection->cartoons->first()->resolved_thumbnail_url); ?>" alt="<?php echo e($collection->name); ?>" loading="lazy"><?php endif; ?>
                                <span><?php echo e($collection->cartoons_count); ?> cartoons</span>
                            </div>
                            <div class="cartoon-collection-copy"><h3><?php echo e($collection->name); ?></h3><p><?php echo e($collection->description); ?></p><span class="collection-link">Explore <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'arrow-right','size' => '14']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','size' => '14']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span></div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="cartoon-empty">Collections will appear here when published artwork is grouped.</div>
                    <?php endif; ?>
                </div>
            </section>
        </div>

        <aside class="cartoon-wear-rail" aria-label="Kipanya Wear preview">
            <?php if($featured): ?>
            <div class="cartoon-wear-panel">
                <div class="cartoon-wear-panel-head">
                    <div><div class="cartoon-kicker"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'shirt','size' => '14']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'shirt','size' => '14']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Make it a T-shirt</div><h2>Wear the art.</h2><p>Start a conversation.</p></div>
                </div>
                <div class="cartoon-wear-preview" data-home-shirt-preview data-color="black" data-size="M" data-placement="front-center">
                    <div class="wear-glow"></div>
                    <div class="real-shirt-photo" aria-label="Blank T-shirt preview"><img src="<?php echo e(asset('assets/wear/shirts/black.png')); ?>" alt="Kipanya T-shirt in Black" data-home-shirt-base="<?php echo e(asset('assets/wear/shirts')); ?>"></div>
                </div>
                <div class="cartoon-wear-controls">
                    <div class="wear-step"><strong>1. Choose Color</strong><div class="wear-color-options">
                        <?php $__currentLoopData = $wearColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button type="button" class="wear-color-dot <?php echo e($key === 'black' ? 'is-selected' : ''); ?>" data-home-color="<?php echo e($key); ?>" style="--dot:<?php echo e($color['hex']); ?>" aria-label="<?php echo e($color['label']); ?>" title="<?php echo e($color['label']); ?>"></button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div></div>
                    <div class="wear-step"><strong>2. Choose Size</strong><div class="wear-size-options"><?php $__currentLoopData = ['XS','S','M','L','XL','XXL']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><button type="button" class="wear-size <?php echo e($size === 'M' ? 'is-selected' : ''); ?>" data-home-size="<?php echo e($size); ?>"><?php echo e($size); ?></button><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></div>
                    <div class="wear-step"><strong>3. Placement</strong><div class="wear-placement-options"><button type="button" class="wear-placement is-selected" data-home-placement="front-center"><span>Front Center</span></button><button type="button" class="wear-placement" data-home-placement="front-pocket"><span>Front Pocket</span></button></div></div>
                    <a href="<?php echo e(route('wear.design', $featured)); ?>?color=black&amp;size=M&amp;placement=front-center" class="cartoon-wear-continue" data-home-wear-continue>Customize &amp; Continue <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'arrow-right','size' => '17']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','size' => '17']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></a>
                </div>
            </div>
            <?php endif; ?>
        </aside>
    </div>
</div>

<script>
(() => {
    const preview = document.querySelector('[data-home-shirt-preview]');
    if (!preview) return;
    const shirt = preview.querySelector('[data-home-shirt-base]');
    const continueLink = document.querySelector('[data-home-wear-continue]');
    const colorButtons = [...document.querySelectorAll('[data-home-color]')];
    const sizeButtons = [...document.querySelectorAll('[data-home-size]')];
    const placementButtons = [...document.querySelectorAll('[data-home-placement]')];
    const base = shirt?.dataset.homeShirtBase || '';
    if (continueLink) continueLink.dataset.baseUrl = continueLink.href.split('?')[0];
    const sync = () => {
        const color = preview.dataset.color || 'black';
        const size = preview.dataset.size || 'M';
        const placement = preview.dataset.placement || 'front-center';
        if (shirt && base) shirt.src = `${base}/${color}.png`;
        colorButtons.forEach((button) => button.classList.toggle('is-selected', button.dataset.homeColor === color));
        sizeButtons.forEach((button) => button.classList.toggle('is-selected', button.dataset.homeSize === size));
        placementButtons.forEach((button) => button.classList.toggle('is-selected', button.dataset.homePlacement === placement));
        if (continueLink) continueLink.href = `${continueLink.dataset.baseUrl}?color=${encodeURIComponent(color)}&size=${encodeURIComponent(size)}&placement=${encodeURIComponent(placement)}`;
    };
    colorButtons.forEach((button) => button.addEventListener('click', () => { preview.dataset.color = button.dataset.homeColor; sync(); }));
    sizeButtons.forEach((button) => button.addEventListener('click', () => { preview.dataset.size = button.dataset.homeSize; sync(); }));
    placementButtons.forEach((button) => button.addEventListener('click', () => { preview.dataset.placement = button.dataset.homePlacement; sync(); }));
    sync();
})();
</script>

<?php if($daily->count()): ?>
<div class="cartoon-story-viewer" data-story-viewer hidden aria-hidden="true">
    <div class="cartoon-story-backdrop" data-story-close></div>
    <div class="cartoon-story-modal" role="dialog" aria-modal="true" aria-label="Daily Cartoon story viewer" tabindex="-1">
        <div class="cartoon-story-progress" data-story-progress aria-hidden="true"></div>
        <button type="button" class="cartoon-story-close" data-story-close aria-label="Close story"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'x','size' => '20']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'x','size' => '20']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></button>
        <button type="button" class="cartoon-story-arrow cartoon-story-prev" data-story-prev aria-label="Previous story"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron-left','size' => '22']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-left','size' => '22']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></button>
        <div class="cartoon-story-art"><img data-story-image src="" alt=""><div class="cartoon-story-shade"></div></div>
        <div class="cartoon-story-copy">
            <div class="cartoon-story-topline"><span class="cartoon-story-account-dot"></span><span>Kipanya Cartoon Archive</span></div>
            <div class="cartoon-section-label" data-story-date></div>
            <h2 data-story-title></h2>
            <p data-story-caption></p>
            <div class="cartoon-story-actions"><a data-story-open class="cartoon-btn cartoon-btn-primary">View Cartoon <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'arrow-right','size' => '15']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','size' => '15']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></a><a data-story-wear class="cartoon-btn cartoon-btn-outline"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'shirt','size' => '15']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'shirt','size' => '15']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Make a T-shirt</a></div>
        </div>
        <button type="button" class="cartoon-story-arrow cartoon-story-next" data-story-next aria-label="Next story"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron-right','size' => '22']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-right','size' => '22']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></button>
    </div>
</div>
<script>
(() => {
    const viewer = document.querySelector('[data-story-viewer]');
    const stories = Array.from(document.querySelectorAll('[data-story-index]'));
    if (!viewer || !stories.length) return;

    const modal = viewer.querySelector('.cartoon-story-modal');
    const art = viewer.querySelector('.cartoon-story-art');
    const image = viewer.querySelector('[data-story-image]');
    const title = viewer.querySelector('[data-story-title]');
    const caption = viewer.querySelector('[data-story-caption]');
    const date = viewer.querySelector('[data-story-date]');
    const openLink = viewer.querySelector('[data-story-open]');
    const wearLink = viewer.querySelector('[data-story-wear]');
    const progress = viewer.querySelector('[data-story-progress]');
    const prev = viewer.querySelector('[data-story-prev]');
    const next = viewer.querySelector('[data-story-next]');
    const duration = 5000;
    let current = 0;
    let timer = null;
    let touchStartX = null;
    let touchStartY = null;
    let paused = false;

    const stopTimer = () => {
        if (timer) clearTimeout(timer);
        timer = null;
    };

    const startTimer = () => {
        stopTimer();
        if (paused || viewer.hidden || stories.length < 2) return;
        timer = setTimeout(() => render(current + 1), duration);
    };

    const renderProgress = () => {
        progress.innerHTML = stories.map((_, index) => {
            const state = index < current ? 'is-complete' : index === current ? 'is-active' : '';
            return `<span class="${state}"><i></i></span>`;
        }).join('');
    };

    const render = (index) => {
        current = (index + stories.length) % stories.length;
        const story = stories[current];
        const src = story.dataset.storyImage || '';
        image.src = src;
        image.alt = story.dataset.storyTitle || 'Daily Cartoon';
        art.style.setProperty('--story-image', `url("${src.replaceAll('"', '%22')}")`);
        title.textContent = story.dataset.storyTitle || '';
        caption.textContent = story.dataset.storyCaption || '';
        caption.hidden = !story.dataset.storyCaption;
        date.textContent = story.dataset.storyDate || '';
        openLink.href = story.dataset.storyDetail || '#';
        wearLink.href = story.dataset.storyWear || '#';
        renderProgress();
        startTimer();
    };

    const show = (index) => {
        viewer.hidden = false;
        viewer.setAttribute('aria-hidden', 'false');
        document.body.classList.add('cartoon-story-open');
        current = index;
        render(current);
        modal.focus({ preventScroll: true });
    };

    const hide = () => {
        stopTimer();
        viewer.hidden = true;
        viewer.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('cartoon-story-open');
    };

    stories.forEach((story, index) => story.addEventListener('click', () => show(index)));
    viewer.querySelectorAll('[data-story-close]').forEach((button) => button.addEventListener('click', hide));
    prev?.addEventListener('click', (event) => { event.stopPropagation(); render(current - 1); });
    next?.addEventListener('click', (event) => { event.stopPropagation(); render(current + 1); });

    art?.addEventListener('pointerdown', (event) => {
        touchStartX = event.clientX;
        touchStartY = event.clientY;
        paused = true;
        stopTimer();
    });

    art?.addEventListener('pointerup', (event) => {
        if (touchStartX === null || touchStartY === null) return;
        const dx = event.clientX - touchStartX;
        const dy = event.clientY - touchStartY;
        touchStartX = touchStartY = null;
        paused = false;
        if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy)) {
            render(dx > 0 ? current - 1 : current + 1);
            return;
        }
        startTimer();
    });

    art?.addEventListener('pointercancel', () => { touchStartX = touchStartY = null; paused = false; startTimer(); });

    viewer.addEventListener('click', (event) => {
        if (event.target.closest('a,button,.cartoon-story-copy')) return;
        const rect = modal.getBoundingClientRect();
        if (event.clientX < rect.left + rect.width * 0.32) render(current - 1);
        else if (event.clientX > rect.left + rect.width * 0.68) render(current + 1);
    });

    // Instagram-style stories should keep progressing on desktop; only direct interaction pauses them.
    document.addEventListener('keydown', (event) => {
        if (viewer.hidden) return;
        if (event.key === 'Escape') hide();
        if (event.key === 'ArrowLeft') { event.preventDefault(); render(current - 1); }
        if (event.key === 'ArrowRight') { event.preventDefault(); render(current + 1); }
    });
})();
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cartoon', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DIGITAL STAR\kipanya-platform\kipanya-platform\resources\views/pages/public/cartoon.blade.php ENDPATH**/ ?>
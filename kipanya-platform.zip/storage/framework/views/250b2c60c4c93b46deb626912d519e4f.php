<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'product',
    'mode' => 'interactive', // interactive | simple | related
    'badge' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'product',
    'mode' => 'interactive', // interactive | simple | related
    'badge' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $isInteractive = $mode === 'interactive';
    $isWishlisted = $isInteractive && auth()->check()
        && auth()->user()->wearWishlists()->where('wear_product_id', $product->id)->exists();

    $productPayload = $isInteractive ? [
        'id' => $product->id,
        'name' => $product->name,
        'slug' => $product->slug,
        'category' => $product->category,
        'price' => (float) $product->price,
        'image' => $product->image_url,
        'url' => route('wear.product', $product),
        'default_variant_id' => optional($product->variants->firstWhere('stock', '>', 0))->id,
        'variants' => $product->variants->map(fn ($v) => [
            'id' => $v->id,
            'size' => $v->size,
            'color' => $v->color,
            'stock' => (int) $v->stock,
        ])->values()->all(),
    ] : null;

    $showBadge = $badge
        ?? ($product->badge ?? null)
        ?? (($product->compare_at_price && $product->compare_at_price > $product->price) ? 'SALE' : null);

    $rating = (float) ($product->approved_reviews_avg_rating ?? 0);
    $reviewCount = (int) ($product->reviews_count ?? 0);
?>

<article
    class="wear-store-product-card"
    <?php if($isInteractive): ?>
        data-product-card
        data-product='<?php echo json_encode($productPayload, 15, 512) ?>'
    <?php endif; ?>
>
    <div class="wear-store-product-image">
        <a href="<?php echo e(route('wear.product', $product)); ?>" class="wear-product-image-link" aria-label="View <?php echo e($product->name); ?>">
            <?php if($showBadge): ?>
                <span class="wear-store-badge <?php echo e(strtolower($showBadge) === 'sale' ? 'sale' : (strtolower($showBadge) === 'best' ? 'best' : '')); ?>">
                    <?php echo e($showBadge); ?>

                </span>
            <?php endif; ?>
            <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" loading="lazy">
        </a>

        <?php if($isInteractive): ?>
            <div class="wear-card-actions">
                <button type="button" data-add-product aria-label="Add <?php echo e($product->name); ?> to cart">
                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'cart','size' => '15']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'cart','size' => '15']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                </button>

                <?php if(auth()->guard()->check()): ?>
                    <form method="POST" action="<?php echo e(route('wear.wishlist.toggle', $product)); ?>" data-wishlist-form>
                        <?php echo csrf_field(); ?>
                        <button
                            type="submit"
                            class="<?php echo e($isWishlisted ? 'is-saved' : ''); ?>"
                            aria-label="<?php echo e($isWishlisted ? 'Remove from wishlist' : 'Save to wishlist'); ?>"
                            aria-pressed="<?php echo e($isWishlisted ? 'true' : 'false'); ?>"
                        >
                            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'heart','size' => '15']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'heart','size' => '15']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        </button>
                    </form>
                <?php else: ?>
                    <button
                        type="button"
                        data-wishlist-local="<?php echo e($product->id); ?>"
                        aria-label="Save for later"
                        aria-pressed="false"
                    >
                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'heart','size' => '15']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'heart','size' => '15']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                    </button>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="wear-store-product-copy">
        <small><?php echo e($product->category); ?></small>
        <a href="<?php echo e(route('wear.product', $product)); ?>">
            <h3><?php echo e($product->name); ?></h3>
        </a>

        <?php if($isInteractive && $reviewCount > 0): ?>
            <div class="wear-card-rating">
                <span>★</span> <?php echo e(number_format($rating, 1)); ?>

                <em>(<?php echo e($reviewCount); ?>)</em>
            </div>
        <?php endif; ?>

        <div class="wear-card-price">
            <strong>TSh <?php echo e(number_format($product->price, 0)); ?></strong>
            <?php if($product->compare_at_price && $product->compare_at_price > $product->price): ?>
                <del>TSh <?php echo e(number_format($product->compare_at_price, 0)); ?></del>
            <?php endif; ?>
        </div>

        <?php if($isInteractive): ?>
            <button type="button" class="wear-card-add" data-add-product>
                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'cart','size' => '15']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'cart','size' => '15']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Add to cart
            </button>
        <?php endif; ?>
    </div>
</article>
<?php /**PATH C:\Users\DIGITAL STAR\kipanya-platform\kipanya-platform\resources\views/components/wear/product-card.blade.php ENDPATH**/ ?>
<!doctype html>
<html lang="en" data-theme="light">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light dark"><title><?php echo e($title ?? 'Kipanya Studio'); ?></title><?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?></head>
<body class="min-h-screen">
<div class="min-h-screen md:flex">
<aside class="hidden w-64 shrink-0 border-r k-divider bg-[var(--surface)] md:block"><div class="sticky top-0 flex h-screen flex-col p-4">
<a href="<?php echo e(route('admin.dashboard')); ?>" class="flex items-center gap-2 px-3 py-3 font-bold tracking-tight"><span class="grid h-8 w-8 place-items-center rounded-xl bg-[var(--accent)] text-white">K</span><span>KIPANYA <span class="font-medium k-muted">STUDIO</span></span></a>
<nav class="mt-8 space-y-1 text-sm"><div class="px-3 pb-2 k-label k-muted">Workspace</div>
<?php $items=[['admin.dashboard','Overview','grid'],['admin.content','Content','film'],['admin.categories','Categories','grid'],['admin.collections','Collections','collection']]; ?>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$route,$label,$icon]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a class="k-nav-link flex items-center gap-3 rounded-xl px-3 py-2.5 <?php echo e(request()->routeIs($route) ? 'active' : ''); ?>" href="<?php echo e(route($route)); ?>"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => ''.e($icon).'','size' => '17']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e($icon).'','size' => '17']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?><?php echo e($label); ?></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</nav>
<div class="mt-auto space-y-1 border-t k-divider pt-4"><button data-theme-toggle class="k-nav-link flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left"><span data-theme-icon data-theme-icon-light='<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>' data-theme-icon-dark='<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20.5 15.5A8.5 8.5 0 0 1 8.5 3.5 8.5 8.5 0 1 0 20.5 15.5Z"/></svg>'></span><span data-theme-label>Dark mode</span></button><a href="<?php echo e(route('home')); ?>" class="k-nav-link flex items-center gap-3 rounded-xl px-3 py-2.5">View public site</a><a href="<?php echo e(route('admin.logout')); ?>" class="k-nav-link flex items-center gap-3 rounded-xl px-3 py-2.5">Sign out</a></div>
</div></aside>
<main class="min-w-0 flex-1"><header class="sticky top-0 z-30 border-b k-divider bg-[var(--bg)]/90 px-4 py-3 backdrop-blur-xl sm:px-6"><div class="flex items-center gap-3"><button data-menu-toggle="#studio-mobile" class="k-btn k-btn-light md:hidden" aria-label="Open navigation"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'menu','size' => '17']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'menu','size' => '17']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></button><div><div class="text-sm font-semibold">Kipanya Studio</div><div class="hidden text-xs k-muted sm:block">Content operations</div></div><div class="ml-auto flex items-center gap-2"><button data-theme-toggle class="k-btn k-btn-light h-9 w-9 p-0"><span data-theme-icon data-theme-icon-light='◐' data-theme-icon-dark='◑'></span></button><a href="<?php echo e(route('admin.logout')); ?>" class="hidden k-btn k-btn-light sm:inline-flex">Sign out</a></div></div></header>
<div id="studio-mobile" class="k-shell hidden border-b k-divider bg-[var(--surface)] py-3 md:hidden"><div class="grid gap-1"><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$route,$label,$icon]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a class="k-nav-link rounded-lg px-3 py-2 <?php echo e(request()->routeIs($route) ? 'active' : ''); ?>" href="<?php echo e(route($route)); ?>"><?php echo e($label); ?></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></div>
<div class="k-shell py-7 md:py-10"><?php echo $__env->yieldContent('content'); ?></div></main></div></body></html>
<?php /**PATH C:\Users\Esrom Mussa\kipanya-platform\resources\views/admin/layout.blade.php ENDPATH**/ ?>
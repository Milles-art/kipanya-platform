<!doctype html>
<html lang="en" data-theme="light">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>{{ $title ?? 'Kipanya Wear' }}</title>
@vite(['resources/css/app.css','resources/css/wear-novashop.css','resources/js/app.js'])
</head>
<body class="kipanya-wear-app antialiased">
<div class="app-shell">
    <aside class="sidebar" id="wear-sidebar">
        <a class="brand" href="{{ route('wear') }}"><span class="brand-mark"><x-icon name="bag" size="19"/></span><span>Kipanya Wear</span></a>
        <nav class="primary-nav">
            <a class="nav-item nav-item-link {{ request()->routeIs('wear') && !request()->query('page') ? 'active' : '' }}" href="{{ route('wear') }}"><x-icon name="home" size="16"/><span>Home</span></a>
            <a class="nav-item nav-item-link {{ request()->routeIs('wear.catalog') ? 'active' : '' }}" href="{{ route('wear.catalog') }}"><x-icon name="grid" size="16"/><span>Categories</span></a>
            <a class="nav-item nav-item-link {{ request()->routeIs('wear.deals') ? 'active' : '' }}" href="{{ route('wear.deals') }}"><x-icon name="tag" size="16"/><span>Deals</span><em>Hot</em></a>
            <a class="nav-item nav-item-link {{ request()->routeIs('wear.new') ? 'active' : '' }}" href="{{ route('wear.new') }}"><x-icon name="sparkles" size="16"/><span>New Arrivals</span></a>
            <a class="nav-item nav-item-link {{ request()->routeIs('wear.best') ? 'active' : '' }}" href="{{ route('wear.best') }}"><x-icon name="star" size="16"/><span>Best Sellers</span></a>
            <a class="nav-item nav-item-link {{ request()->routeIs('wear.brands') ? 'active' : '' }}" href="{{ route('wear.brands') }}"><x-icon name="shield" size="16"/><span>Brands</span></a>
            <a class="nav-item nav-item-link {{ request()->routeIs('wear.collections') ? 'active' : '' }}" href="{{ route('wear.collections') }}"><x-icon name="collection" size="16"/><span>Collections</span></a>
        </nav>
        <div class="nav-divider"></div><div class="nav-label">Your account</div>
        <a class="nav-item nav-item-link {{ request()->routeIs('wear.orders') ? 'active' : '' }}" href="{{ route('wear.orders') }}"><x-icon name="package" size="16"/><span>My Orders</span></a>
        <a class="nav-item nav-item-link {{ request()->routeIs('wear.wishlist') ? 'active' : '' }}" href="{{ route('wear.wishlist') }}"><x-icon name="heart" size="16"/><span>Wishlist</span></a>
        <a class="nav-item nav-item-link {{ request()->routeIs('wear.coupons') ? 'active' : '' }}" href="{{ route('wear.coupons') }}"><x-icon name="tag" size="16"/><span>Coupons</span></a>
        <a class="nav-item nav-item-link {{ request()->routeIs('wear.addresses') ? 'active' : '' }}" href="{{ route('wear.addresses') }}"><x-icon name="location" size="16"/><span>Addresses</span></a>
        <a class="nav-item nav-item-link {{ request()->routeIs('wear.settings') ? 'active' : '' }}" href="{{ route('wear.settings') }}"><x-icon name="settings" size="16"/><span>Account Settings</span></a>
        <div class="summer-card"><span>Special Offer</span><strong>Summer Sale</strong><small>Up to 50% Off</small><a href="{{ route('wear.deals') }}" class="nav-item-link"><button type="button">Shop Now <x-icon name="arrow-right" size="13"/></button></a><div class="sale-spark">%</div></div>
        <div class="help-link"><x-icon name="help" size="16"/><div><strong>Need Help?</strong><span>24/7 Support Center</span></div></div>
        <button class="light-mode" type="button" data-theme-toggle><span>☼</span><span data-theme-label>Light mode</span><x-icon name="chevron" size="15"/></button>
    </aside>
    <div class="overlay" data-wear-overlay></div>
    <main class="main-content">
        <header class="topbar">
            <button class="mobile-menu" type="button" data-wear-menu><x-icon name="menu" size="20"/></button>
            <form class="search-box" action="{{ route('wear.search') }}" method="GET"><x-icon name="search" size="16"/><input name="q" value="{{ request('q') }}" placeholder="Search for products, brands and more..." aria-label="Search"><kbd>⌘ K</kbd></form>
            <div class="top-actions">
                <a class="wish-top" href="{{ route('wear.wishlist') }}"><x-icon name="heart" size="17"/><span>Wishlist</span></a>
                <button class="bell" type="button" data-wear-toast="You are all caught up"><x-icon name="bell" size="18"/><b>3</b></button>
                <a class="wish-top cart-top" href="{{ route('wear.cart') }}"><x-icon name="bag" size="18"/><span>Cart</span>@php $wearCartCount = app(\App\Services\Commerce\WearCartService::class)->count(request()); @endphp @if($wearCartCount)<b>{{ $wearCartCount }}</b>@endif</a>
                <a class="profile" href="{{ auth()->check() ? route('account') : route('account.login') }}"><div class="avatar">{{ auth()->user()?->name ? mb_strtoupper(mb_substr(auth()->user()->name,0,2)) : 'KW' }}</div><span>{{ auth()->user()?->name ?? 'Guest' }}</span><x-icon name="chevron-down" size="13"/></a>
            </div>
        </header>
        @if(session('cart_status'))<div class="flash">{{ session('cart_status') }}</div>@endif
        @if(session('order_status'))<div class="flash">{{ session('order_status') }}</div>@endif
        @yield('content')
    </main>
</div>
<div id="wear-toast" class="toast" hidden></div>
<script>
document.addEventListener('DOMContentLoaded',()=>{
 const sidebar=document.getElementById('wear-sidebar'), overlay=document.querySelector('[data-wear-overlay]');
 document.querySelector('[data-wear-menu]')?.addEventListener('click',()=>sidebar.classList.add('open'));
 overlay?.addEventListener('click',()=>sidebar.classList.remove('open'));
 document.querySelectorAll('.sidebar a').forEach(a=>a.addEventListener('click',()=>sidebar.classList.remove('open')));
 const toast=document.getElementById('wear-toast'); let timer;
 document.addEventListener('click',e=>{const b=e.target.closest('[data-wear-toast]'); if(!b)return; toast.textContent=b.dataset.wearToast; toast.hidden=false; clearTimeout(timer); timer=setTimeout(()=>toast.hidden=true,2600);});
 document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();document.querySelector('.search-box input')?.focus();} if(e.key==='Escape')sidebar.classList.remove('open');});
});
</script>
<script>
(function(){const key='kipanya_wear_wishlist';const read=()=>{try{return JSON.parse(localStorage.getItem(key)||'[]')}catch{return[]}};const write=v=>localStorage.setItem(key,JSON.stringify(v.slice(0,50)));function sync(){const ids=read().map(String);document.querySelectorAll('[data-wish]').forEach(b=>{const on=ids.includes(String(b.dataset.wish));b.classList.toggle('liked',on);b.setAttribute('aria-pressed',on?'true':'false');const svg=b.querySelector('svg');if(svg)svg.setAttribute('fill',on?'currentColor':'none')});}document.addEventListener('click',e=>{const b=e.target.closest('[data-wish]');if(!b)return;e.preventDefault();e.stopPropagation();const id=String(b.dataset.wish),ids=read().map(String);write(ids.includes(id)?ids.filter(x=>x!==id):[id,...ids]);sync()});sync()})();
</script>
@stack('scripts')
</body></html>

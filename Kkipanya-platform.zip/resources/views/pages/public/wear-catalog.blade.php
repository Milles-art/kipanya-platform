@extends('layouts.wear')
@section('content')
<div class="store-page catalog-page">
 <div class="page-heading"><div><span class="eyebrow">Kipanya Wear</span><h1>{{ $title }}</h1><p>{{ $copy }}</p></div><div class="catalog-meta"><span>{{ $products->total() }} pieces</span></div></div>
 @if($categories->count())<div class="category-strip">@foreach($categories as $category)<a href="{{ route('wear.catalog',['category'=>$category]) }}"><button class="{{ request('category')===$category ? 'active' : '' }}"><span>♧</span>{{ $category }}</button></a>@endforeach</div>@endif
 <div class="catalog-grid">@forelse($products as $product)<x-wear.nova-product-card :product="$product"/>@empty<div class="empty-card" style="grid-column:1/-1"><div><x-icon name="search" size="26"/></div><h2>No products found</h2><span>Try another search or category.</span><a class="primary-button" href="{{ route('wear.catalog') }}">View all products <x-icon name="arrow-right" size="15"/></a></div>@endforelse</div>
 @if($products->hasPages())<div class="pagination">{{ $products->onEachSide(1)->links('pagination::simple-tailwind') }}</div>@endif
</div>
@endsection

<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['cartoon']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['cartoon']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $format = $cartoon->artwork_format ?: 'landscape';
    $aspect = match($format) { 'portrait' => '3 / 4', 'square' => '1 / 1', default => '4 / 3' };
?>
<article class="cartoon-react-card" data-cartoon-card data-href="<?php echo e(route('cartoon.detail', $cartoon)); ?>" tabindex="0" role="link" aria-label="View <?php echo e($cartoon->title); ?>">
    <div class="cartoon-card-media" style="--card-aspect:<?php echo e($aspect); ?>">
        <?php if($cartoon->resolved_thumbnail_url): ?><img src="<?php echo e($cartoon->resolved_thumbnail_url); ?>" alt="<?php echo e($cartoon->title); ?>" loading="lazy"><?php else: ?><div class="cartoon-art-placeholder">K</div><?php endif; ?>
        <div class="cartoon-card-gradient"></div>
        <div class="cartoon-card-category"><?php echo e($cartoon->category?->name ?? 'Cartoon'); ?></div>
        <div class="cartoon-card-fav"><?php if (isset($component)) { $__componentOriginald49144e894a817670bd797b36f84d701 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald49144e894a817670bd797b36f84d701 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cartoon.favorite-button','data' => ['cartoon' => $cartoon,'size' => 'sm','saved' => $cartoon->getAttribute('is_favorited')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cartoon.favorite-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['cartoon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($cartoon),'size' => 'sm','saved' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($cartoon->getAttribute('is_favorited'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald49144e894a817670bd797b36f84d701)): ?>
<?php $attributes = $__attributesOriginald49144e894a817670bd797b36f84d701; ?>
<?php unset($__attributesOriginald49144e894a817670bd797b36f84d701); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald49144e894a817670bd797b36f84d701)): ?>
<?php $component = $__componentOriginald49144e894a817670bd797b36f84d701; ?>
<?php unset($__componentOriginald49144e894a817670bd797b36f84d701); ?>
<?php endif; ?></div>
        <div class="cartoon-card-overlay"><h3><?php echo e($cartoon->title); ?></h3><span><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'calendar','size' => '12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'calendar','size' => '12']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> <?php echo e($cartoon->published_at?->format('d M Y') ?? 'Archive'); ?></span></div>
    </div>
    <div class="cartoon-card-footer"><p><?php echo e($cartoon->caption ?: \Illuminate\Support\Str::limit($cartoon->description, 80)); ?></p><span class="cartoon-card-arrow"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'arrow-right','size' => '15']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','size' => '15']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span></div>
</article>
<?php /**PATH C:\Users\DIGITAL STAR\kipanya-platform\kipanya-platform\resources\views/components/cartoon/card.blade.php ENDPATH**/ ?>
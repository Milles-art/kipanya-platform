<?php $__env->startSection('content'); ?>
<div class="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between"><div><div class="k-label k-muted">Library</div><h1 class="mt-2 text-3xl font-semibold tracking-tight sm:text-4xl">Content</h1><p class="mt-2 text-sm k-muted">Manage every cartoon in the public library.</p></div><button class="k-btn k-btn-primary">New cartoon</button></div>
<div class="mt-7 k-card overflow-hidden"><div class="flex flex-col gap-3 border-b k-divider p-4 sm:flex-row"><div class="k-control flex min-w-0 flex-1 items-center gap-2 rounded-xl px-3"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'search','size' => '16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'search','size' => '16']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?><input placeholder="Search content" class="w-full bg-transparent py-2 text-sm outline-none"></div><button class="k-btn k-btn-light">All statuses</button><button class="k-btn k-btn-light">Filter</button></div><div class="overflow-x-auto"><table class="w-full min-w-[700px] text-left text-sm"><thead class="border-b k-divider text-[10px] uppercase tracking-[.12em] k-muted"><tr><th class="px-5 py-4">Title</th><th class="px-5 py-4">Category</th><th class="px-5 py-4">Status</th><th class="px-5 py-4">Published</th><th class="px-5 py-4"></th></tr></thead><tbody class="divide-y k-divider"><?php $__empty_1 = true; $__currentLoopData = $cartoons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartoon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr class="transition hover:bg-[var(--surface-2)]"><td class="px-5 py-4"><div class="flex items-center gap-3"><div class="h-10 w-14 overflow-hidden rounded-lg k-thumb"><?php if($cartoon->thumbnail_url): ?><img src="<?php echo e($cartoon->thumbnail_url); ?>" alt="" class="h-full w-full object-cover"><?php endif; ?></div><span class="font-semibold"><?php echo e($cartoon->title); ?></span></div></td><td class="px-5 py-4 k-muted"><?php echo e($cartoon->category->name); ?></td><td class="px-5 py-4"><span class="k-status <?php echo e($cartoon->status?->value === 'published' ? 'k-status-published' : 'k-status-draft'); ?>"><?php echo e(ucfirst($cartoon->status?->value)); ?></span></td><td class="px-5 py-4 k-muted"><?php echo e(optional($cartoon->published_at)->format('d M Y') ?? '—'); ?></td><td class="px-5 py-4 text-right k-muted">•••</td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="5" class="px-5 py-14 text-center k-muted">No cartoons have been added yet.</td></tr><?php endif; ?></tbody></table></div><div class="border-t k-divider px-5 py-4"><?php echo e($cartoons->links()); ?></div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Esrom Mussa\kipanya-platform\resources\views/admin/content/index.blade.php ENDPATH**/ ?>
<!doctype html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="color-scheme" content="dark light">
    <script>
        (() => {
            try {
                const saved = localStorage.getItem('kipanya-theme');
                if (saved === 'light' || saved === 'dark') document.documentElement.dataset.theme = saved;
            } catch (_) {}
        })();
    </script>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($title ?? 'Cartoon Archive — Kipanya'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
</head>
<body class="antialiased kipanya-platform cartoon-client">
<?php if (isset($component)) { $__componentOriginal561a05b5eb862a3bdec2028663814664 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal561a05b5eb862a3bdec2028663814664 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.client-nav','data' => ['activeApp' => 'cartoons','brandSubtitle' => 'Cartoon Archive','searchAction' => ''.e(route('cartoon.search')).'','searchPlaceholder' => 'Search cartoons, characters, stories...','searchLabel' => 'Search cartoons, characters and stories','showFavorites' => true,'showCart' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('client-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['active-app' => 'cartoons','brand-subtitle' => 'Cartoon Archive','search-action' => ''.e(route('cartoon.search')).'','search-placeholder' => 'Search cartoons, characters, stories...','search-label' => 'Search cartoons, characters and stories','show-favorites' => true,'show-cart' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal561a05b5eb862a3bdec2028663814664)): ?>
<?php $attributes = $__attributesOriginal561a05b5eb862a3bdec2028663814664; ?>
<?php unset($__attributesOriginal561a05b5eb862a3bdec2028663814664); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal561a05b5eb862a3bdec2028663814664)): ?>
<?php $component = $__componentOriginal561a05b5eb862a3bdec2028663814664; ?>
<?php unset($__componentOriginal561a05b5eb862a3bdec2028663814664); ?>
<?php endif; ?>

<main><?php echo $__env->yieldContent('content'); ?></main>

<footer class="cartoon-react-footer">
    <div class="cartoon-shell cartoon-footer-grid">
        <div><a href="<?php echo e(route('home')); ?>" class="platform-wordmark footer-brand"><span class="platform-mark">K</span><span>Kipanya</span></a><p>One ecosystem. Five worlds. The Cartoon Archive is the home for illustrated stories.</p></div>
        <div class="cartoon-footer-links"><a href="<?php echo e(route('cartoon')); ?>">Cartoons</a><a href="<?php echo e(route('cartoon.search')); ?>">Search</a><a href="<?php echo e(auth()->check() ? route('favorites') : route('account.login')); ?>">Favorites</a><a href="<?php echo e(route('collections')); ?>">Collections</a><a href="<?php echo e(route('home')); ?>">Kipanya</a></div>
    </div>
</footer>
</body>
</html>
<?php /**PATH C:\Users\DIGITAL STAR\kipanya-platform\kipanya-platform\resources\views/layouts/cartoon.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<section class="k-shell pt-6 sm:pt-10">
<div class="k-hero relative overflow-hidden rounded-[28px] p-6 sm:p-10 lg:p-12">
<div class="relative z-10 grid min-h-[430px] items-end gap-8 lg:grid-cols-[1fr_300px]">
<div class="max-w-2xl k-reveal"><div class="inline-flex items-center gap-2 rounded-full border k-divider bg-[var(--surface)]/80 px-3 py-1.5 text-[11px] font-semibold"><span class="h-1.5 w-1.5 rounded-full bg-[var(--accent)]"></span> New stories every week</div><h1 class="k-display mt-6 text-5xl font-semibold sm:text-7xl">Stories that inspire <span class="text-[var(--accent)]">imagination.</span></h1><p class="mt-6 max-w-xl text-base leading-7 k-muted sm:text-lg">Discover African cartoons, memorable characters and episodes made for curious minds and loyal fans.</p><div class="mt-7 flex flex-wrap gap-3"><a href="<?php echo e(route('discover')); ?>" class="k-btn k-btn-primary">Start watching <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'play','size' => '15']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'play','size' => '15']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></a><a href="#featured" class="k-btn k-btn-light">Explore featured</a></div></div>
<div class="hidden rounded-2xl border k-divider bg-[var(--surface)]/75 p-4 backdrop-blur lg:block k-reveal k-delay-2"><div class="k-label k-muted">Featured now</div><?php if($featured->first()): ?><div class="mt-4 aspect-[4/3] overflow-hidden rounded-xl k-thumb"><?php if($featured->first()->thumbnail_url): ?><img src="<?php echo e($featured->first()->thumbnail_url); ?>" alt="<?php echo e($featured->first()->title); ?>" class="h-full w-full object-cover"><?php endif; ?></div><div class="mt-3 font-semibold"><?php echo e($featured->first()->title); ?></div><a href="<?php echo e(route('watch',$featured->first())); ?>" class="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-[var(--accent)]">Watch episode <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron','size' => '13']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron','size' => '13']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></a><?php else: ?><div class="mt-4 aspect-[4/3] rounded-xl k-thumb"></div><?php endif; ?></div>
</div><div class="absolute -right-24 -top-24 h-80 w-80 rounded-full bg-[var(--accent)]/15 blur-3xl"></div><div class="absolute bottom-0 right-1/4 h-48 w-48 rounded-full bg-orange-300/20 blur-3xl"></div>
</div>
</section>
<?php if($featured->count()): ?><section id="featured" class="k-shell py-16"><div class="flex items-end justify-between gap-4"><div><div class="k-label k-muted">Featured</div><h2 class="mt-2 text-2xl font-semibold tracking-tight sm:text-3xl">What fans are watching</h2></div><a href="<?php echo e(route('discover')); ?>" class="text-sm font-semibold text-[var(--accent)]">View all</a></div><div class="mt-7 grid gap-4 sm:grid-cols-2 lg:grid-cols-3"><?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartoon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e(route('watch',$cartoon)); ?>" class="k-card group"><div class="relative aspect-[16/10] overflow-hidden k-thumb"><?php if($cartoon->thumbnail_url): ?><img src="<?php echo e($cartoon->thumbnail_url); ?>" alt="<?php echo e($cartoon->title); ?>" class="h-full w-full object-cover transition duration-500 group-hover:scale-105"><?php endif; ?><div class="absolute left-3 top-3 rounded-full bg-black/65 px-2.5 py-1 text-[10px] font-semibold text-white">Featured</div><span class="absolute bottom-3 right-3 grid h-9 w-9 place-items-center rounded-full bg-white text-black shadow-lg"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'play','size' => '14']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'play','size' => '14']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span></div><div class="p-5"><div class="k-label k-muted"><?php echo e($cartoon->category->name); ?></div><div class="mt-2 text-lg font-semibold"><?php echo e($cartoon->title); ?></div><p class="mt-2 line-clamp-2 text-sm leading-6 k-muted"><?php echo e($cartoon->description); ?></p></div></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></section><?php endif; ?>
<?php if($collections->count()): ?><section class="border-y k-divider bg-[var(--surface)]"><div class="k-shell py-16"><div class="k-label k-muted">Curated worlds</div><h2 class="mt-2 text-2xl font-semibold tracking-tight sm:text-3xl">Explore collections</h2><div class="mt-8 space-y-12"><?php $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><div class="flex items-end justify-between gap-4"><div><h3 class="text-xl font-semibold"><?php echo e($collection->name); ?></h3><?php if($collection->description): ?><p class="mt-1 text-sm k-muted"><?php echo e($collection->description); ?></p><?php endif; ?></div><a href="<?php echo e(route('collection',$collection)); ?>" class="hidden text-sm font-semibold text-[var(--accent)] sm:inline">View collection</a></div><div class="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3"><?php $__currentLoopData = $collection->cartoons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartoon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e(route('watch',$cartoon)); ?>" class="group"><div class="aspect-[4/3] overflow-hidden rounded-2xl k-thumb"><?php if($cartoon->thumbnail_url): ?><img src="<?php echo e($cartoon->thumbnail_url); ?>" alt="<?php echo e($cartoon->title); ?>" class="h-full w-full object-cover transition duration-500 group-hover:scale-105"><?php endif; ?></div><div class="mt-3 font-semibold"><?php echo e($cartoon->title); ?></div><div class="mt-1 text-xs k-muted"><?php echo e($cartoon->category->name); ?></div></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></div></section><?php endif; ?>
<?php if($categories->count()): ?><section class="k-shell py-16"><div class="k-label k-muted">Browse by world</div><h2 class="mt-2 text-2xl font-semibold tracking-tight sm:text-3xl">Find your kind of story</h2><div class="mt-7 grid gap-3 sm:grid-cols-2 lg:grid-cols-4"><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e(route('category',$category)); ?>" class="k-card p-5"><div class="flex items-center justify-between gap-4"><div><div class="text-base font-semibold"><?php echo e($category->name); ?></div><div class="mt-1 text-xs k-muted"><?php echo e($category->cartoons_count); ?> <?php echo e(Str::plural('cartoon',$category->cartoons_count)); ?></div></div><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron','size' => '17','class' => 'text-[var(--accent)]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron','size' => '17','class' => 'text-[var(--accent)]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></div></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></section><?php endif; ?>
<section id="latest" class="border-t k-divider"><div class="k-shell py-16"><div class="flex items-end justify-between gap-4"><div><div class="k-label k-muted">Latest</div><h2 class="mt-2 text-2xl font-semibold tracking-tight sm:text-3xl">New on Kipanya</h2></div><a href="<?php echo e(route('discover')); ?>" class="text-sm font-semibold text-[var(--accent)]">Browse library</a></div><div class="mt-7 grid gap-5 sm:grid-cols-2 lg:grid-cols-4"><?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartoon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e(route('watch',$cartoon)); ?>" class="group"><div class="relative aspect-[4/3] overflow-hidden rounded-2xl k-thumb"><?php if($cartoon->thumbnail_url): ?><img src="<?php echo e($cartoon->thumbnail_url); ?>" alt="<?php echo e($cartoon->title); ?>" class="h-full w-full object-cover transition duration-500 group-hover:scale-105"><?php endif; ?></div><div class="mt-3 font-semibold"><?php echo e($cartoon->title); ?></div><div class="mt-1 text-xs k-muted"><?php echo e($cartoon->category->name); ?></div></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Esrom Mussa\kipanya-platform\resources\views/pages/public/home.blade.php ENDPATH**/ ?>
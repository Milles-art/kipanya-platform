<?php $__env->startSection('content'); ?>
<?php
    $variantPayload = $product->variants->map(function ($variant) {
        return [
            'id' => $variant->id,
            'size' => $variant->size,
            'color' => $variant->color,
            'stock' => (int) $variant->stock,
        ];
    })->values()->all();
    $hasSale = $product->compare_at_price && $product->compare_at_price > $product->price;
?>

<div class="wear-product-detail">
    <div class="wear-breadcrumb">
        <a href="<?php echo e(route('wear')); ?>">Wear</a><span>/</span><span><?php echo e($product->category); ?></span><span>/</span><strong><?php echo e($product->name); ?></strong>
    </div>

    <div class="wear-detail-grid">
        <div class="wear-detail-gallery">
            <div class="wear-detail-main">
                <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>">
            </div>
            <div class="wear-detail-thumbs" aria-label="Product images">
                <button type="button" class="is-active" aria-label="<?php echo e($product->name); ?> preview">
                    <img src="<?php echo e($product->image_url); ?>" alt="">
                </button>
            </div>
        </div>

        <div class="wear-detail-copy">
            <div class="wear-detail-overline">
                <span class="wear-product-badge"><?php echo e($product->badge ?? 'Kipanya Wear'); ?></span>
                <span><?php echo e($product->category); ?></span>
            </div>

            <h1><?php echo e($product->name); ?></h1>
            <div class="wear-detail-rating" aria-label="Rated 4.9 out of 5">
                <span aria-hidden="true">★★★★★</span><span class="wear-rating-copy">4.9 · Kipanya Wear</span>
            </div>

            <div class="wear-detail-price-wrap">
                <div class="wear-detail-price">TSh <?php echo e(number_format($product->price, 0)); ?></div>
                <?php if($hasSale): ?>
                    <del>TSh <?php echo e(number_format($product->compare_at_price, 0)); ?></del>
                    <span class="wear-detail-sale">Sale</span>
                <?php endif; ?>
            </div>

            <p><?php echo e($product->description); ?></p>

            <?php if($product->variants->count()): ?>
                <form method="POST" action="<?php echo e(route('wear.cart.items.store')); ?>" id="wear-product-form">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="variant_id" id="wear-variant-id" value="">
                    <input type="hidden" name="quantity" id="wear-quantity" value="1">

                    <div class="wear-detail-field">
                        <label>Size</label>
                        <div class="wear-size-grid" data-size-grid>
                            <?php $__currentLoopData = $product->variants->pluck('size')->unique()->values(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <button type="button" data-size="<?php echo e($size); ?>"><?php echo e($size); ?></button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <div class="wear-detail-field">
                        <label>Color</label>
                        <div class="wear-color-grid" data-color-grid>
                            <?php $__currentLoopData = $product->variants->pluck('color')->unique()->values(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <button type="button" data-color="<?php echo e($color); ?>">
                                    <i style="background:<?php echo e($color === 'white' ? '#f8fafc' : ($color === 'navy' ? '#1e3a5f' : ($color === 'teal' ? '#0f766e' : ($color === 'blue' ? '#3b82f6' : ($color === 'olive' ? '#66704d' : ($color === 'natural' ? '#d7c7a4' : '#111827')))))); ?>"></i>
                                    <?php echo e(ucfirst($color)); ?>

                                </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <div class="wear-variant-status" data-variant-status role="status" aria-live="polite">Choose a size and color.</div>

                    <div class="wear-detail-field">
                        <label>Quantity</label>
                        <div class="wear-qty">
                            <button type="button" data-qty-minus aria-label="Decrease quantity">−</button>
                            <span data-qty-value>1</span>
                            <button type="button" data-qty-plus aria-label="Increase quantity">+</button>
                        </div>
                    </div>

                    <button class="wear-btn wear-btn-gold wear-detail-add" type="submit">
                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'cart','size' => '18']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'cart','size' => '18']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Add to cart
                    </button>
                </form>
            <?php else: ?>
                <div class="wear-alert">This product is currently unavailable.</div>
            <?php endif; ?>

            <a class="wear-buy-btn wear-buy-link" href="<?php echo e(route('wear')); ?>">Continue shopping</a>

            <div class="wear-detail-notes">
                <span><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'package','size' => '17']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'package','size' => '17']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Fast delivery across Tanzania</span>
                <span><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'shield','size' => '17']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'shield','size' => '17']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Secure checkout</span>
                <span><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'heart','size' => '17']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'heart','size' => '17']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Made with care</span>
            </div>
        </div>
    </div>

    <?php if($related->count()): ?>
        <section class="wear-related" aria-labelledby="related-products-heading">
            <div class="wear-store-section-head">
                <div>
                    <span>YOU MAY ALSO LIKE</span>
                    <h2 id="related-products-heading">More from <?php echo e($product->category); ?></h2>
                    <p>Keep the rotation going with pieces from the same collection.</p>
                </div>
                <a href="<?php echo e(route('wear', ['category' => $product->category])); ?>">View category <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'arrow-right','size' => '15']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','size' => '15']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></a>
            </div>
            <div class="wear-store-product-grid">
                <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="wear-store-product-card" href="<?php echo e(route('wear.product', $item)); ?>">
                        <div class="wear-store-product-image">
                            <?php if($item->badge): ?>
                                <span class="wear-store-badge"><?php echo e($item->badge); ?></span>
                            <?php elseif($item->compare_at_price && $item->compare_at_price > $item->price): ?>
                                <span class="wear-store-badge sale">Sale</span>
                            <?php endif; ?>
                            <img src="<?php echo e($item->image_url); ?>" alt="<?php echo e($item->name); ?>" loading="lazy">
                        </div>
                        <div class="wear-store-product-copy">
                            <small><?php echo e($item->category); ?></small>
                            <h3><?php echo e($item->name); ?></h3>
                            <strong>TSh <?php echo e(number_format($item->price, 0)); ?></strong>
                            <?php if($item->compare_at_price && $item->compare_at_price > $item->price): ?>
                                <del>TSh <?php echo e(number_format($item->compare_at_price, 0)); ?></del>
                            <?php endif; ?>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    <?php endif; ?>
</div>

<script>
(function () {
    const form = document.getElementById('wear-product-form');
    if (!form) return;

    const variants = <?php echo json_encode($variantPayload, 15, 512) ?>;
    const id = document.getElementById('wear-variant-id');
    const quantityInput = document.getElementById('wear-quantity');
    const status = form.querySelector('[data-variant-status]');
    const quantityLabel = form.querySelector('[data-qty-value]');
    let size = null;
    let color = null;
    let quantity = 1;

    function firstAvailable(filter) {
        return variants.find((variant) => variant.stock > 0 && (!filter || filter(variant)));
    }

    const first = firstAvailable();
    size = first?.size ?? null;
    color = first?.color ?? null;

    function currentVariant() {
        return variants.find((variant) => variant.size === size && variant.color === color && variant.stock > 0) || null;
    }

    function render() {
        form.querySelectorAll('[data-size]').forEach((button) => {
            const selected = button.dataset.size === size;
            button.classList.toggle('is-selected', selected);
            button.setAttribute('aria-pressed', selected ? 'true' : 'false');
        });

        form.querySelectorAll('[data-color]').forEach((button) => {
            const selected = button.dataset.color === color;
            button.classList.toggle('is-selected', selected);
            button.setAttribute('aria-pressed', selected ? 'true' : 'false');
        });

        const variant = currentVariant();
        if (variant) {
            quantity = Math.max(1, Math.min(quantity, variant.stock));
            id.value = variant.id;
            status.textContent = variant.stock + ' available';
            status.classList.add('is-ready');
        } else {
            id.value = '';
            status.textContent = 'That size and color combination is unavailable.';
            status.classList.remove('is-ready');
        }

        quantityInput.value = quantity;
        quantityLabel.textContent = quantity;
        form.querySelector('[type="submit"]').disabled = !variant;
    }

    form.querySelectorAll('[data-size]').forEach((button) => {
        button.addEventListener('click', () => {
            size = button.dataset.size;
            if (!variants.some((variant) => variant.size === size && variant.color === color && variant.stock > 0)) {
                color = firstAvailable((variant) => variant.size === size)?.color ?? color;
            }
            render();
        });
    });

    form.querySelectorAll('[data-color]').forEach((button) => {
        button.addEventListener('click', () => {
            color = button.dataset.color;
            if (!variants.some((variant) => variant.size === size && variant.color === color && variant.stock > 0)) {
                size = firstAvailable((variant) => variant.color === color)?.size ?? size;
            }
            render();
        });
    });

    form.querySelector('[data-qty-minus]')?.addEventListener('click', () => {
        quantity = Math.max(1, quantity - 1);
        render();
    });

    form.querySelector('[data-qty-plus]')?.addEventListener('click', () => {
        const maximum = currentVariant()?.stock ?? 20;
        quantity = Math.min(maximum, quantity + 1);
        render();
    });

    render();
})();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.wear', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DIGITAL STAR\kipanya-platform\kipanya-platform\resources\views/pages/public/wear-product.blade.php ENDPATH**/ ?>
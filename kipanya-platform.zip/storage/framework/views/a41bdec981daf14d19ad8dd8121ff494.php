<?php $__env->startSection('content'); ?>
<section class="k-shell py-12 sm:py-16">
    <a href="<?php echo e(route('discover')); ?>" class="text-sm text-black/45 hover:text-black">Back to library</a>
    <div class="mt-10 max-w-3xl"><div class="k-label text-black/40">Collection</div><h1 class="k-display mt-4 text-5xl font-semibold sm:text-7xl"><?php echo e($collection->name); ?></h1><?php if($collection->description): ?><p class="mt-6 text-lg leading-8 text-black/55"><?php echo e($collection->description); ?></p><?php endif; ?></div>
    <?php if($collection->cartoons->count()): ?>
        <div class="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            <?php $__currentLoopData = $collection->cartoons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartoon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('watch', $cartoon)); ?>" class="k-card group"><div class="aspect-[16/10] overflow-hidden bg-[#ecece9]"><?php if($cartoon->thumbnail_url): ?><img src="<?php echo e($cartoon->thumbnail_url); ?>" alt="<?php echo e($cartoon->title); ?>" class="h-full w-full object-cover transition duration-500 group-hover:scale-[1.03]"><?php endif; ?></div><div class="p-5"><div class="k-label text-black/35"><?php echo e($cartoon->category->name); ?></div><h2 class="mt-2 text-xl font-semibold"><?php echo e($cartoon->title); ?></h2></div></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="mt-10 rounded-3xl bg-[#f7f7f5] px-6 py-16 text-center text-sm text-black/50">This collection is being prepared.</div>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Esrom Mussa\kipanya-platform\resources\views/pages/public/collection.blade.php ENDPATH**/ ?>
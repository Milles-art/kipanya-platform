@extends('layouts.cartoon')
@section('content')
<div class="cartoon-social-page" data-cartoon-page>
    <section class="cartoon-profile-card">
        <div class="cartoon-profile-cover">
            @if($featured?->resolved_thumbnail_url)
                <img src="{{ $featured->resolved_thumbnail_url }}" alt="" loading="eager">
            @endif
            <span class="cartoon-profile-cover-glow"></span>
        </div>
        <div class="cartoon-profile-body">
            <div class="cartoon-profile-avatar">K</div>
            <div class="cartoon-profile-copy">
                <div class="cartoon-profile-title"><h1>Kipanya Cartoons</h1><span class="cartoon-verified" aria-label="Kipanya archive"><x-icon name="check-circle" size="13"/></span></div>
                <p>Daily observations, drawn with a little mischief.</p>
                <span class="cartoon-profile-handle">@kipanya.archive · Dar es Salaam</span>
            </div>
            <div class="cartoon-profile-actions"><a href="{{ route('discover') }}" class="cartoon-outline-button">Explore archive</a></div>
        </div>
        <div class="cartoon-profile-stats"><span><strong>{{ $latest->count() }}</strong> latest posts</span><span><strong>{{ $daily->count() }}</strong> daily stories</span><span><strong>{{ $collections->count() }}</strong> collections</span></div>
        <nav class="cartoon-profile-tabs" aria-label="Cartoon sections"><a href="#feed" class="active"><x-icon name="grid" size="15"/> Feed</a><a href="{{ route('discover') }}"><x-icon name="search" size="15"/> Discover</a><a href="#collections"><x-icon name="collection" size="15"/> Collections</a></nav>
    </section>

    @if($daily->count())
    <section class="cartoon-daily cartoon-social-stories" id="daily-stories">
        <div class="cartoon-social-section-head"><div><span class="public-kicker">Fresh today</span><h2>Daily stories</h2></div><span class="cartoon-story-hint">Tap to open</span></div>
        <div class="cartoon-stories" aria-label="Daily cartoons">
            @foreach($daily as $story)
                <button type="button" class="cartoon-story" data-story-index data-story-image="{{ $story->resolved_thumbnail_url }}" data-story-title="{{ $story->title }}" data-story-caption="{{ $story->caption }}" data-story-date="{{ optional($story->daily_date ?? $story->published_at)->format('d M Y') }}" data-story-detail="{{ route('cartoon.detail', $story) }}" data-story-wear="{{ route('wear.design', $story) }}">
                    <span class="cartoon-story-ring"><img src="{{ $story->resolved_thumbnail_url }}" alt="{{ $story->title }}" loading="lazy"></span><strong>{{ \Illuminate\Support\Str::limit($story->title, 18) }}</strong>
                </button>
            @endforeach
        </div>
    </section>
    @endif

    <div class="cartoon-social-columns" id="feed">
        <section class="cartoon-feed-column">
            <div class="cartoon-feed-heading"><div><span class="public-kicker">The latest</span><h2>From the archive</h2></div><a href="{{ route('discover') }}">View all <x-icon name="arrow-right" size="14"/></a></div>
            @forelse($latest as $cartoon)
                <x-cartoon.feed-post :cartoon="$cartoon"/>
            @empty
                <div class="cartoon-empty cartoon-empty-large"><h2>The archive is warming up.</h2><p>New cartoons will appear here soon.</p></div>
            @endforelse
        </section>

        <aside class="cartoon-social-aside">
            <section class="cartoon-aside-card cartoon-aside-about">
                <span class="public-kicker">About this feed</span>
                <h2>Small drawings.<br><em>Big observations.</em></h2>
                <p>A living collection of cartoons about everyday life, culture, work and the things we all quietly notice.</p>
                <a href="{{ route('discover') }}">Browse the full archive <x-icon name="arrow-right" size="14"/></a>
            </section>
            @if($categories->count())
            <section class="cartoon-aside-card">
                <div class="cartoon-aside-heading"><h3>Browse themes</h3><a href="{{ route('discover') }}">All</a></div>
                <div class="cartoon-theme-list">@foreach($categories->take(5) as $category)<a href="{{ route('category', $category) }}"><span>{{ $category->name }}</span><small>{{ $category->cartoons_count ?? 0 }}</small><x-icon name="arrow-right" size="13"/></a>@endforeach</div>
            </section>
            @endif
            @if($collections->count())
            <section class="cartoon-aside-card" id="collections">
                <div class="cartoon-aside-heading"><h3>Curated collections</h3><a href="{{ route('collections') }}">All</a></div>
                <div class="cartoon-mini-collections">@foreach($collections->take(3) as $collection)<a href="{{ route('collection', $collection) }}">@php($c=$collection->cartoons->first())<span>@if($c?->resolved_thumbnail_url)<img src="{{ $c->resolved_thumbnail_url }}" alt="">@endif</span><strong>{{ $collection->name }}</strong><small>{{ $collection->cartoons_count ?? $collection->cartoons->count() }} cartoons</small></a>@endforeach</div>
            </section>
            @endif
        </aside>
    </div>
</div>
@if($daily->count())
<div class="cartoon-story-viewer" data-story-viewer hidden aria-hidden="true"><div class="cartoon-story-backdrop" data-story-close></div><div class="cartoon-story-modal" role="dialog" aria-modal="true" aria-label="Daily Cartoon viewer" tabindex="-1"><div class="cartoon-story-progress" data-story-progress></div><button class="cartoon-story-close" data-story-close aria-label="Close"><x-icon name="x" size="20"/></button><button class="cartoon-story-arrow cartoon-story-prev" data-story-prev aria-label="Previous"><x-icon name="chevron-left" size="22"/></button><div class="cartoon-story-art"><img data-story-image src="" alt=""></div><div class="cartoon-story-copy"><span class="public-kicker" data-story-date></span><h2 data-story-title></h2><p data-story-caption></p><div class="public-home-actions"><a class="public-button public-button-dark" data-story-open>View cartoon <x-icon name="arrow-right" size="15"/></a><a class="public-button public-button-quiet" data-story-wear>Make a T-shirt</a></div></div><button class="cartoon-story-arrow cartoon-story-next" data-story-next aria-label="Next"><x-icon name="chevron-right" size="22"/></button></div></div>
<script>
(() => { const viewer=document.querySelector('[data-story-viewer]'), stories=[...document.querySelectorAll('[data-story-index]')]; if(!viewer||!stories.length)return; const modal=viewer.querySelector('.cartoon-story-modal'), image=viewer.querySelector('[data-story-image]'), title=viewer.querySelector('[data-story-title]'), caption=viewer.querySelector('[data-story-caption]'), date=viewer.querySelector('[data-story-date]'), open=viewer.querySelector('[data-story-open]'), wear=viewer.querySelector('[data-story-wear]'), progress=viewer.querySelector('[data-story-progress]'); let i=0,timer; const draw=()=>{const s=stories[i]; image.src=s.dataset.storyImage; image.alt=s.dataset.storyTitle; title.textContent=s.dataset.storyTitle; caption.textContent=s.dataset.storyCaption||''; caption.hidden=!s.dataset.storyCaption; date.textContent=s.dataset.storyDate||''; open.href=s.dataset.storyDetail; wear.href=s.dataset.storyWear; progress.innerHTML=stories.map((_,n)=>`<span class="${n<i?'done':''} ${n===i?'active':''}"></span>`).join(''); clearTimeout(timer); timer=setTimeout(()=>{i=(i+1)%stories.length;draw()},5000)}; const show=n=>{i=(n+stories.length)%stories.length;viewer.hidden=false;document.body.classList.add('story-open');draw();modal.focus({preventScroll:true})}; const hide=()=>{viewer.hidden=true;document.body.classList.remove('story-open');clearTimeout(timer)}; stories.forEach((s,n)=>s.addEventListener('click',()=>show(n))); viewer.querySelectorAll('[data-story-close]').forEach(b=>b.addEventListener('click',hide)); viewer.querySelector('[data-story-prev]').addEventListener('click',()=>{i--;draw()}); viewer.querySelector('[data-story-next]').addEventListener('click',()=>{i++;draw()}); document.addEventListener('keydown',e=>{if(viewer.hidden)return;if(e.key==='Escape')hide();if(e.key==='ArrowLeft'){i--;draw()}if(e.key==='ArrowRight'){i++;draw()}}); })();
</script>
@endif
@endsection

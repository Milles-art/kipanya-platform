<?php $__env->startSection('content'); ?>
<div class="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between"><div><div class="k-label k-muted">Overview</div><h1 class="mt-2 text-3xl font-semibold tracking-tight sm:text-4xl">Good to see you.</h1><p class="mt-2 text-sm k-muted">A clear view of the Kipanya library.</p></div><a href="<?php echo e(route('admin.content')); ?>" class="k-btn k-btn-primary">Manage content <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron','size' => '14']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron','size' => '14']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></a></div>
<div class="mt-7 grid gap-3 sm:grid-cols-2 lg:grid-cols-5"><?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div class="k-card p-5"><div class="flex items-center justify-between"><div class="k-label k-muted"><?php echo e(ucfirst($label)); ?></div><span class="text-[var(--accent)]"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => ''.e($label === 'episodes' ? 'film' : 'grid').'','size' => '16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e($label === 'episodes' ? 'film' : 'grid').'','size' => '16']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span></div><div class="mt-5 text-3xl font-semibold tracking-tight"><?php echo e($value); ?></div><div class="mt-2 text-xs k-muted">Current total</div></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
<div class="mt-7 grid gap-5 xl:grid-cols-[1.35fr_.65fr]"><section class="k-card"><div class="flex items-center justify-between border-b k-divider px-5 py-4"><div><h2 class="font-semibold">Recent content</h2><p class="mt-1 text-xs k-muted">Latest additions to the library.</p></div><a class="text-xs font-semibold text-[var(--accent)]" href="<?php echo e(route('admin.content')); ?>">View all</a></div><div class="divide-y k-divider"><?php $__empty_1 = true; $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartoon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><div class="flex items-center gap-4 px-5 py-4"><div class="h-11 w-14 shrink-0 overflow-hidden rounded-lg k-thumb"><?php if($cartoon->thumbnail_url): ?><img src="<?php echo e($cartoon->thumbnail_url); ?>" alt="" class="h-full w-full object-cover"><?php endif; ?></div><div class="min-w-0 flex-1"><div class="truncate text-sm font-semibold"><?php echo e($cartoon->title); ?></div><div class="mt-1 text-xs k-muted"><?php echo e($cartoon->category->name); ?> · <?php echo e(ucfirst($cartoon->status?->value)); ?></div></div><div class="hidden text-xs k-muted sm:block"><?php echo e(optional($cartoon->published_at)->format('d M Y') ?? 'Unpublished'); ?></div></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="px-5 py-12 text-center text-sm k-muted">No content yet.</div><?php endif; ?></div></section><section class="k-card p-5"><div class="k-label k-muted">Publishing snapshot</div><div class="mt-5 text-5xl font-semibold tracking-tight"><?php echo e($stats['published']); ?></div><p class="mt-2 text-sm k-muted">published cartoons</p><div class="mt-7 h-2 overflow-hidden rounded-full bg-[var(--surface-2)]"><div class="h-full rounded-full bg-[var(--accent)]" style="width:<?php echo e($stats['cartoons'] ? min(100, round(($stats['published']/$stats['cartoons'])*100)) : 0); ?>%"></div></div><div class="mt-3 flex justify-between text-xs k-muted"><span>Published</span><span><?php echo e($stats['cartoons'] ? round(($stats['published']/$stats['cartoons'])*100) : 0); ?>%</span></div></section></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Esrom Mussa\kipanya-platform\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal87246244e5e03dfa16004a41d2229e4d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87246244e5e03dfa16004a41d2229e4d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.platform.home','data' => ['featured' => $featured,'latest' => $latest,'categories' => $categories,'collections' => $collections]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('platform.home'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['featured' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($featured),'latest' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($latest),'categories' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categories),'collections' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($collections)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87246244e5e03dfa16004a41d2229e4d)): ?>
<?php $attributes = $__attributesOriginal87246244e5e03dfa16004a41d2229e4d; ?>
<?php unset($__attributesOriginal87246244e5e03dfa16004a41d2229e4d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87246244e5e03dfa16004a41d2229e4d)): ?>
<?php $component = $__componentOriginal87246244e5e03dfa16004a41d2229e4d; ?>
<?php unset($__componentOriginal87246244e5e03dfa16004a41d2229e4d); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DIGITAL STAR\kipanya-platform\kipanya-platform\resources\views/pages/public/home.blade.php ENDPATH**/ ?>
@extends('layouts.cartoon')
@section('content')
<div class="public-cartoon" data-cartoon-page>
    @if($daily->count())
    <section class="cartoon-daily" id="daily-stories">
        <div class="public-section-head cartoon-head"><div><span class="public-kicker">Every day</span><h1>Today’s Cartoon</h1></div><span class="cartoon-story-hint">Tap a story to open</span></div>
        <div class="cartoon-stories" aria-label="Daily cartoons">
            @foreach($daily as $story)
                <button type="button" class="cartoon-story" data-story-index data-story-image="{{ $story->resolved_thumbnail_url }}" data-story-title="{{ $story->title }}" data-story-caption="{{ $story->caption }}" data-story-date="{{ optional($story->daily_date ?? $story->published_at)->format('d M Y') }}" data-story-detail="{{ route('cartoon.detail', $story) }}" data-story-wear="{{ route('wear.design', $story) }}">
                    <span class="cartoon-story-ring"><img src="{{ $story->resolved_thumbnail_url }}" alt="{{ $story->title }}" loading="lazy"></span><strong>{{ \Illuminate\Support\Str::limit($story->title, 18) }}</strong>
                </button>
            @endforeach
        </div>
    </section>
    @endif

    @if($featured)
    <section class="cartoon-featured">
        <div class="cartoon-featured-art"><img src="{{ $featured->resolved_thumbnail_url }}" alt="{{ $featured->title }}"></div>
        <div class="cartoon-featured-copy"><span class="public-kicker">Featured cartoon</span><h2>{{ $featured->title }}</h2><p>{{ $featured->caption ?: $featured->description }}</p><div class="cartoon-meta"><span>{{ $featured->category?->name ?? 'Editorial' }}</span><span>{{ optional($featured->published_at)->format('d M Y') }}</span></div><a class="public-button public-button-dark" href="{{ route('cartoon.detail', $featured) }}">Read the cartoon <x-icon name="arrow-right" size="16"/></a></div>
    </section>
    @endif

    @if($latest->count())
    <section class="public-home-section" id="latest">
        <div class="public-section-head"><div><span class="public-kicker">The archive</span><h2>Latest cartoons.</h2></div><a href="{{ route('discover') }}">Search archive <x-icon name="arrow-right" size="15"/></a></div>
        <div class="cartoon-masonry">
            @foreach($latest as $cartoon)
                <a href="{{ route('cartoon.detail', $cartoon) }}" class="cartoon-masonry-card"><img src="{{ $cartoon->resolved_thumbnail_url }}" alt="{{ $cartoon->title }}" loading="lazy"><div><span>{{ $cartoon->category?->name ?? 'Cartoon' }}</span><h3>{{ $cartoon->title }}</h3><small>{{ optional($cartoon->published_at)->format('d M Y') }}</small></div></a>
            @endforeach
        </div>
    </section>
    @endif

    @if($categories->count())
    <section class="public-home-section" id="categories"><div class="public-section-head"><div><span class="public-kicker">Browse by theme</span><h2>Categories.</h2></div></div><div class="cartoon-category-list">@foreach($categories as $category)<a href="{{ route('category', $category) }}"><span>{{ $category->name }}</span><strong>{{ $category->cartoons_count ?? 0 }}</strong><x-icon name="arrow-right" size="16"/></a>@endforeach</div></section>
    @endif

    @if($collections->count())
    <section class="public-home-section"><div class="public-section-head"><div><span class="public-kicker">Curated archive</span><h2>Collections.</h2></div><a href="{{ route('collections') }}">All collections <x-icon name="arrow-right" size="15"/></a></div><div class="public-collection-strip">@foreach($collections as $collection)<a href="{{ route('collection', $collection) }}" class="public-collection-card">@php($c=$collection->cartoons->first())@if($c?->resolved_thumbnail_url)<img src="{{ $c->resolved_thumbnail_url }}" alt="" loading="lazy">@endif<div><span>Collection</span><h3>{{ $collection->name }}</h3><p>{{ $collection->cartoons->count() }} cartoons</p></div></a>@endforeach</div></section>
    @endif
</div>
@if($daily->count())
<div class="cartoon-story-viewer" data-story-viewer hidden aria-hidden="true"><div class="cartoon-story-backdrop" data-story-close></div><div class="cartoon-story-modal" role="dialog" aria-modal="true" aria-label="Daily Cartoon viewer" tabindex="-1"><div class="cartoon-story-progress" data-story-progress></div><button class="cartoon-story-close" data-story-close aria-label="Close"><x-icon name="x" size="20"/></button><button class="cartoon-story-arrow cartoon-story-prev" data-story-prev aria-label="Previous"><x-icon name="chevron-left" size="22"/></button><div class="cartoon-story-art"><img data-story-image src="" alt=""></div><div class="cartoon-story-copy"><span class="public-kicker" data-story-date></span><h2 data-story-title></h2><p data-story-caption></p><div class="public-home-actions"><a class="public-button public-button-dark" data-story-open>View cartoon <x-icon name="arrow-right" size="15"/></a><a class="public-button public-button-quiet" data-story-wear>Make a T-shirt</a></div></div><button class="cartoon-story-arrow cartoon-story-next" data-story-next aria-label="Next"><x-icon name="chevron-right" size="22"/></button></div></div>
<script>
(() => { const viewer=document.querySelector('[data-story-viewer]'), stories=[...document.querySelectorAll('[data-story-index]')]; if(!viewer||!stories.length)return; const modal=viewer.querySelector('.cartoon-story-modal'), image=viewer.querySelector('[data-story-image]'), title=viewer.querySelector('[data-story-title]'), caption=viewer.querySelector('[data-story-caption]'), date=viewer.querySelector('[data-story-date]'), open=viewer.querySelector('[data-story-open]'), wear=viewer.querySelector('[data-story-wear]'), progress=viewer.querySelector('[data-story-progress]'); let i=0,timer; const draw=()=>{const s=stories[i]; image.src=s.dataset.storyImage; image.alt=s.dataset.storyTitle; title.textContent=s.dataset.storyTitle; caption.textContent=s.dataset.storyCaption||''; caption.hidden=!s.dataset.storyCaption; date.textContent=s.dataset.storyDate||''; open.href=s.dataset.storyDetail; wear.href=s.dataset.storyWear; progress.innerHTML=stories.map((_,n)=>`<span class="${n<i?'done':''} ${n===i?'active':''}"></span>`).join(''); clearTimeout(timer); timer=setTimeout(()=>{i=(i+1)%stories.length;draw()},5000)}; const show=n=>{i=(n+stories.length)%stories.length;viewer.hidden=false;document.body.classList.add('story-open');draw();modal.focus({preventScroll:true})}; const hide=()=>{viewer.hidden=true;document.body.classList.remove('story-open');clearTimeout(timer)}; stories.forEach((s,n)=>s.addEventListener('click',()=>show(n))); viewer.querySelectorAll('[data-story-close]').forEach(b=>b.addEventListener('click',hide)); viewer.querySelector('[data-story-prev]').addEventListener('click',()=>{i--;draw()}); viewer.querySelector('[data-story-next]').addEventListener('click',()=>{i++;draw()}); document.addEventListener('keydown',e=>{if(viewer.hidden)return;if(e.key==='Escape')hide();if(e.key==='ArrowLeft'){i--;draw()}if(e.key==='ArrowRight'){i++;draw()}}); })();
</script>
@endif
@endsection
